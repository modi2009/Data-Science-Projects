# (Dataset Exploration Title)
## by (your name here)


## Dataset

> data cosists of 183412 rows and 16 columns before modification I have dropped null values and 2 columns (start station id,end station id) and added a column (day) which is the day of the week from the column (start time) so the dataset becomes 174952 rows and 15 columns the data talks about bikes trip in February 2019 in  San Francisco CA US , the columns are (duration_sec,bike_id,start_time,end_time,start_station_name,start_station_latitude,start_station_longitude,end_station_name,end_station_latitude,end_station_longitude,user_type,member_birth_year,member_gender,bike_share_for_all_trip,day)
you can find the data from https://www.kaggle.com/chirag02/ford-gobike-data-analysis
 

## Summary of Findings

> In the exploration I've found that although weekends had less trips but regarding duration of trips weekend were more than ordinary days. Also most trips duration were between 600-800 seconds and although the male had more trips than female but the reverese was regarding trip duration. Whan I countplot the type of users I've found that subscribers were much more than customer but when I put it in relation with duration of trips the customer had much more duration per trip. finally in the multivariant from the 2 visualization I found that male are much more in the whole week but more from Monday to Friday while Female and others have much more trip in the weekend also I have see that the relation between trip duration is more with others then Female then Male , the same thing is seen with relation between subscribers customers and trip duration although subscriber have much more trip than customers but customers tend to have much trip duration especially in the weekend


## Key Insights for Presentation

> the intersting relationship is that the reason why riding the bike affect the trip duration so if you you routinley ride bicycle your number of trip will increase but the duration of trip will be less